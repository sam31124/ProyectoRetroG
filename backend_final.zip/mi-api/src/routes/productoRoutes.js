const express = require('express');
const router = express.Router();
// Importamos el guardia que acabamos de crear
const authMiddleware = require('../middleware/authMiddleware'); 

// RUTA PÚBLICA (Cualquiera puede ver productos)
router.get('/', (req, res) => {
    res.json({ mensaje: "Lista de productos (Pública)" });
});

// 🔒 RUTA PROTEGIDA (Solo con Token se puede crear)
// Fíjate que ponemos 'authMiddleware' antes de la función
router.post('/', authMiddleware, (req, res) => {
    // Si llega aquí, es porque el token era válido
    res.json({ 
        mensaje: "Producto creado exitosamente", 
        usuario_que_lo_creo: req.usuario // Gracias al middleware sabemos quién fue
    });
});

module.exports = router;