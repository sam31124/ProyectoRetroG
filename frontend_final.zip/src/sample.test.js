describe('Prueba básica', () => {
  it('debe sumar correctamente', () => {
    const suma = 2 + 2;
    expect(suma).toBe(4);
  });
});
